public interface Algorithm {
    <E extends Comparable<E>> E[] sort(E[] arr);
}
