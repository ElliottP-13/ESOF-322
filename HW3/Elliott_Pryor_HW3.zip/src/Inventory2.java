public class Inventory2 extends Inventory{
    public Inventory2(){
        this.sAlg = new MergeSort();
    }
}
