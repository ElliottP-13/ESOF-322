public class Inventory4 extends Inventory{
    public Inventory4(){
        this.sAlg = new BubbleSort();
    }
}
