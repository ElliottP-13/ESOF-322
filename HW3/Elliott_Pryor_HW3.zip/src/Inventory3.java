public class Inventory3 extends Inventory{
    public Inventory3(){
        this.sAlg = new QuickSort();
    }
}
