public class Inventory1 extends Inventory{

    public Inventory1(){
        this.sAlg = new BogoSort();
    }
}
